<?php get_header(); ?>
<a href="<?php echo esc_url( home_url( 'http://my-website.local/shop-2/' ) ); ?>">Shop</a>
<div class="shop-container">
    <h2>Our Books</h2>
    <div class="shop-products">
        <?php if ( have_posts() ) : ?>
            <?php while ( have_posts() ) : the_post(); ?>
            <?php $product = wc_get_product(get_the_ID()); ?>
                <div class="product-item">
                    <a href="<?php the_permalink(); ?>">
                        <div class="product-image">
                            <?php  if ( has_post_thumbnail() ) {
                                    the_post_thumbnail('woocommerce_thumbnail'); // Adjust size as needed
                                } ?>
                        </div>
                        <div class="product-title">
                            <h3><?php the_title(); ?></h3>
                        </div>
                        <div class="product-price">
                            <?php echo $product->get_price_html(); ?>
                        </div>
                    </a>
                </div>
            <?php endwhile; ?>
        <?php else : ?>
            <p>No products found</p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>