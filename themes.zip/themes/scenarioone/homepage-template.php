<?php get_header(); ?>

<div class="home-content">
    <h1>Anisha Bookstore </h1>
    <h2>Welcome to the Anisha Bookstore in the Online version</h2>
    <p>Here, you can find your favorite and new some intresting book!</p>
    <div class="featured-products">
        <?php
        // Display Featured Products
        echo do_shortcode('[products limit="4" columns="4" orderby="date" visibility="featured"]');
        ?>
    </div>
</div>

<?php get_footer(); ?>