<?php 
/**
 * This is the default Homepage template file for assignment.
 */
get_header();
?>
 <section class="default-page" style="bacground: url('<?php $featuredImg[0];?>')">
    <div>
    <link rel="stylesheet" href="<?php echo esc_url(home_url('wp-content/themes/scenarioone/css/custom-styles.css')); ?>">
        <h1>Anisha BookStore</h1>
        
        <p> Here, you can look for our book collections. </p>
    </div>
  </section>
 <?php
 get_footer();
 ?>