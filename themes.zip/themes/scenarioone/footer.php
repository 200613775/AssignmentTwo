<footer>
    <p>&copy; Anisha bookstore. All rights reserved. </p>

</footer>
<?php wp_footer(); ?>
</body>
</html>